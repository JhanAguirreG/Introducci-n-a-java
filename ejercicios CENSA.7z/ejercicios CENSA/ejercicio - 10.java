
public class operaciones {
 
    public static void main(String[] args) {
 
        //Declaramos las variables
        int num1=90;
        int num2=45;
 
        /*Realizamos las operaciones.
         * Tambien lo podemos guardar el resultado en variables. */
 
        System.out.println("El resultado de la suma es "+(num1+num2));
 
        System.out.println("El resultado de la resta es "+(num1-num2));
 
        System.out.println("El resultado de la multiplicación es "+(num1*num2));
 
        System.out.println("El resultado de la división es "+(num1/num2));
    }
}
