public class hola {
 
    public static void main(String[] args) {
 
        String nombre=" Doug Dimmadome, dueño del Domodín de Dimmsdale!";
 
        System.out.println("Bienvenido "+nombre);
    }
}

