public class BucleInfinito {
 
    public static void main(String[] args) {
 
        int num=1;
 
        //Definimos el bucle, incluye el 100
        while (num<=100){
            System.out.println(num);
            //Incrementamos num
            num++;
        }
    }
}


