import javax.swing.JOptionPane;
public class main {
    public static void main(String[] args) {
        int num1=1;
        int num2=2;
        System.out.println("el resultado de la suma es"+(num1+num2));
        System.out.println("el resultado de la resta es"+(num1-num2));
        System.out.println("el resultado de la multiplicaccion es"+(num1*num2));
        System.out.println("el resultado de la division es"+(num1/num2));
        System.out.println("hola mundo");

        if (num1>=num2){
            if(num1==num2){
                System.out.println("lon numero"+num1+"y"+num2+"son iguales");
            }else{
                System.out.println("el numero"+num1+"es mayor que el numero"+num2);
            }
        }else{
            System.out.println("el numero"+num2+"es mayor que"+num1);
      
            
        }
        
        String nombre= "yef";
        System.out.println("bienvenido"+nombre);
    
    }
    {
        String nombre=JOptionPane.showInputDialog("Introduce tu nombre");
 
        System.out.println("Bienvenido "+nombre);
}

}